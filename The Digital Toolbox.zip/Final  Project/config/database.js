const mysql = require('mysql2');
require('dotenv').config();

// Create connection pool with error handling
let pool;
let dbConnected = false;

try {
    pool = mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        database: process.env.DB_NAME || 'digital_toolbox',
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
    });

    // Get promise-based connection
    const promisePool = pool.promise();

    // Test connection
    pool.getConnection((err, connection) => {
        if (err) {
            console.log('⚠️  Database not available - running in demo mode');
            dbConnected = false;
        } else {
            console.log('✅ Database connected successfully');
            dbConnected = true;
            connection.release();
        }
    });

    module.exports = promisePool;
    module.exports.isConnected = () => dbConnected;
} catch (error) {
    console.log('⚠️  Database configuration error - running in demo mode');
    module.exports = null;
    module.exports.isConnected = () => false;
}

// Fallback data for demo mode
const fallbackServices = [
    {
        id: 1,
        name: 'PayPal Solutions',
        description: 'Verified PayPal account setup and integration services for seamless online payments. We help you get your business payments running smoothly with verified accounts.',
        icon: 'fa-paypal',
        category: 'payment'
    },
    {
        id: 2,
        name: 'Stripe Integration',
        description: 'Complete Stripe payment gateway setup with verified accounts for your business. Accept payments securely with our expert integration services.',
        icon: 'fa-stripe',
        category: 'payment'
    },
    {
        id: 3,
        name: 'LLC Registration',
        description: 'Professional LLC registration support to establish your business legally. We guide you through the entire process from start to finish.',
        icon: 'fa-building',
        category: 'business'
    },
    {
        id: 4,
        name: 'Graphic Design',
        description: 'Creative and professional graphic design services for your brand identity. Logo design, branding, marketing materials, and more.',
        icon: 'fa-palette',
        category: 'design'
    },
    {
        id: 5,
        name: 'Digital Marketing',
        description: 'Comprehensive digital marketing strategies to grow your online presence. SEO, social media marketing, content marketing, and paid advertising.',
        icon: 'fa-chart-line',
        category: 'marketing'
    },
    {
        id: 6,
        name: 'Premium Resources',
        description: 'Access to premium digital resources, templates, and tools for your business. Curated collections of assets to boost your productivity.',
        icon: 'fa-gem',
        category: 'resources'
    }
];

module.exports.getFallbackServices = () => fallbackServices;
