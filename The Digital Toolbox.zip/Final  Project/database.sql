-- The Digital Toolbox Database Schema
-- Create database
CREATE DATABASE IF NOT EXISTS digital_toolbox;
USE digital_toolbox;

-- Services table
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    icon VARCHAR(100),
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contact inquiries table
CREATE TABLE IF NOT EXISTS inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    service VARCHAR(255),
    message TEXT NOT NULL,
    status ENUM('new', 'in_progress', 'completed') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Newsletter subscribers table
CREATE TABLE IF NOT EXISTS subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default services
INSERT INTO services (name, description, icon, category) VALUES
('PayPal Solutions', 'Verified PayPal account setup and integration services for seamless online payments', 'fa-paypal', 'payment'),
('Stripe Integration', 'Complete Stripe payment gateway setup with verified accounts for your business', 'fa-stripe', 'payment'),
('LLC Registration', 'Professional LLC registration support to establish your business legally', 'fa-building', 'business'),
('Graphic Design', 'Creative and professional graphic design services for your brand identity', 'fa-palette', 'design'),
('Digital Marketing', 'Comprehensive digital marketing strategies to grow your online presence', 'fa-chart-line', 'marketing'),
('Premium Resources', 'Access to premium digital resources, templates, and tools for your business', 'fa-gem', 'resources');
