const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get all services
router.get('/services', async (req, res) => {
    try {
        // Check if database is connected
        if (!db || !db.isConnected()) {
            // Return fallback data
            return res.json({ 
                success: true, 
                data: require('../config/database').getFallbackServices(),
                demo: true 
            });
        }

        const [rows] = await db.query('SELECT * FROM services ORDER BY id');
        res.json({ success: true, data: rows });
    } catch (error) {
        console.error('Error fetching services:', error);
        // Return fallback data on error
        res.json({ 
            success: true, 
            data: require('../config/database').getFallbackServices(),
            demo: true 
        });
    }
});

// Get service by ID
router.get('/services/:id', async (req, res) => {
    try {
        // Check if database is connected
        if (!db || !db.isConnected()) {
            const fallbackServices = require('../config/database').getFallbackServices();
            const service = fallbackServices.find(s => s.id === parseInt(req.params.id));
            
            if (!service) {
                return res.status(404).json({ success: false, message: 'Service not found' });
            }
            return res.json({ success: true, data: service, demo: true });
        }

        const [rows] = await db.query('SELECT * FROM services WHERE id = ?', [req.params.id]);
        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Service not found' });
        }
        res.json({ success: true, data: rows[0] });
    } catch (error) {
        console.error('Error fetching service:', error);
        res.status(500).json({ success: false, message: 'Error fetching service' });
    }
});

// Submit contact inquiry
router.post('/inquiries', async (req, res) => {
    try {
        const { name, email, phone, service, message } = req.body;
        
        // Validation
        if (!name || !email || !message) {
            return res.status(400).json({ 
                success: false, 
                message: 'Name, email, and message are required' 
            });
        }

        // Check if database is connected
        if (!db || !db.isConnected()) {
            console.log('Demo mode - Inquiry saved locally:', { name, email, phone, service, message });
            return res.json({ 
                success: true, 
                message: 'Your inquiry has been submitted successfully! (Demo Mode)',
                demo: true
            });
        }

        const [result] = await db.query(
            'INSERT INTO inquiries (name, email, phone, service, message) VALUES (?, ?, ?, ?, ?)',
            [name, email, phone || null, service || null, message]
        );

        res.json({ 
            success: true, 
            message: 'Your inquiry has been submitted successfully!',
            id: result.insertId 
        });
    } catch (error) {
        console.error('Error submitting inquiry:', error);
        res.status(500).json({ success: false, message: 'Error submitting inquiry' });
    }
});

// Get all inquiries (admin)
router.get('/inquiries', async (req, res) => {
    try {
        // Check if database is connected
        if (!db || !db.isConnected()) {
            return res.json({ 
                success: true, 
                data: [],
                demo: true,
                message: 'Running in demo mode - no database connection' 
            });
        }

        const [rows] = await db.query('SELECT * FROM inquiries ORDER BY created_at DESC');
        res.json({ success: true, data: rows });
    } catch (error) {
        console.error('Error fetching inquiries:', error);
        res.status(500).json({ success: false, message: 'Error fetching inquiries' });
    }
});

// Subscribe to newsletter
router.post('/subscribe', async (req, res) => {
    try {
        const { email } = req.body;
        
        if (!email) {
            return res.status(400).json({ 
                success: false, 
                message: 'Email is required' 
            });
        }

        // Check if database is connected
        if (!db || !db.isConnected()) {
            console.log('Demo mode - Subscriber added:', { email });
            return res.json({ 
                success: true, 
                message: 'Successfully subscribed to newsletter! (Demo Mode)',
                demo: true
            });
        }

        // Check if already subscribed
        const [existing] = await db.query('SELECT * FROM subscribers WHERE email = ?', [email]);
        if (existing.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'This email is already subscribed' 
            });
        }

        await db.query('INSERT INTO subscribers (email) VALUES (?)', [email]);
        res.json({ 
            success: true, 
            message: 'Successfully subscribed to newsletter!' 
        });
    } catch (error) {
        console.error('Error subscribing:', error);
        res.status(500).json({ success: false, message: 'Error subscribing to newsletter' });
    }
});

// Get all subscribers (admin)
router.get('/subscribers', async (req, res) => {
    try {
        // Check if database is connected
        if (!db || !db.isConnected()) {
            return res.json({ 
                success: true, 
                data: [],
                demo: true,
                message: 'Running in demo mode - no database connection' 
            });
        }

        const [rows] = await db.query('SELECT * FROM subscribers ORDER BY subscribed_at DESC');
        res.json({ success: true, data: rows });
    } catch (error) {
        console.error('Error fetching subscribers:', error);
        res.status(500).json({ success: false, message: 'Error fetching subscribers' });
    }
});

// Health check endpoint
router.get('/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        timestamp: new Date().toISOString(),
        demo: !db || !db.isConnected()
    });
});

module.exports = router;
