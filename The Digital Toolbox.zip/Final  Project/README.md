# The Digital Toolbox - Modern Full-Stack Web Application

A modern, responsive full-stack web application for The Digital Toolbox digital agency, providing verified PayPal & Stripe solutions, LLC registration support, graphic design, digital marketing, and premium digital resources.

## 🚀 Features

### Frontend Features
- **Modern Design**: Sleek, dark-themed UI with gradient accents
- **Fully Responsive**: Works perfectly on desktop, tablet, and mobile devices
- **Animated Elements**: Smooth animations and transitions throughout
- **Interactive Services**: Dynamic service cards loaded from API
- **Contact Form**: Fully functional contact form with validation
- **Newsletter Subscription**: Email subscription functionality
- **Smooth Scrolling**: Navigation with smooth scroll effects
- **Counter Animation**: Animated statistics with number counters
- **Parallax Effects**: Background shapes with parallax scrolling
- **Custom Cursor**: Optional custom cursor effect on desktop

### Backend Features
- **RESTful API**: Complete REST API with Express.js
- **Database Integration**: MySQL database with fallback demo mode
- **Service Management**: Dynamic service retrieval from database
- **Contact Inquiries**: Form submission with database storage
- **Newsletter System**: Email subscription management
- **Error Handling**: Comprehensive error handling and validation
- **Demo Mode**: Works without database connection for testing

## 🛠️ Technologies Used

### Frontend
- **HTML5**: Semantic HTML structure
- **CSS3**: Modern CSS with variables, animations, and responsive design
- **JavaScript (ES6+)**: Vanilla JavaScript for interactivity
- **Font Awesome**: Icon library
- **Google Fonts**: Poppins font family

### Backend
- **Node.js**: JavaScript runtime
- **Express.js**: Web application framework
- **MySQL**: Database management system
- **mysql2**: MySQL driver for Node.js

## 📋 Prerequisites

Before running the application, ensure you have:

1. **Node.js** (v14 or higher) installed
2. **MySQL** (optional - app works in demo mode without it) installed and running
3. **npm** or **yarn** package manager

## 🚦 Getting Started

### 1. Clone or Download the Project

```bash
git clone <repository-url>
cd digital-toolbox
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Database Setup (Optional)

If you want to use the full database functionality:

1. Start MySQL server
2. Create the database:
```bash
mysql -u root -p < database.sql
```

3. Update `.env` file with your database credentials:
```
DB_HOST=localhost
DB_USER=your_username
DB_PASSWORD=your_password
DB_NAME=digital_toolbox
```

### 4. Start the Server

```bash
npm start
```

The application will be available at: **http://localhost:3000**

### 5. Demo Mode

The application works perfectly without MySQL - it will run in demo mode with fallback data. This is perfect for:
- Development and testing
- Demonstrations
- Quick setup without database configuration

## 📁 Project Structure

```
digital-toolbox/
├── config/
│   └── database.js         # Database configuration
├── public/
│   ├── css/
│   │   └── style.css       # Main stylesheet
│   ├── js/
│   │   └── main.js         # Frontend JavaScript
│   ├── images/             # Image assets
│   └── index.html          # Main HTML file
├── routes/
│   └── api.js              # API routes
├── .env                    # Environment variables
├── database.sql            # Database schema
├── package.json            # Dependencies
├── server.js               # Express server
└── README.md               # Documentation
```

## 🎯 API Endpoints

### Services
- `GET /api/services` - Get all services
- `GET /api/services/:id` - Get service by ID

### Contact
- `POST /api/inquiries` - Submit contact inquiry

### Newsletter
- `POST /api/subscribe` - Subscribe to newsletter

### Admin
- `GET /api/inquiries` - Get all inquiries
- `GET /api/subscribers` - Get all subscribers
- `GET /api/health` - Health check endpoint

## 🎨 Services Provided

1. **PayPal Solutions** - Verified PayPal account setup and integration
2. **Stripe Integration** - Complete Stripe payment gateway setup
3. **LLC Registration** - Professional LLC registration support
4. **Graphic Design** - Creative and professional design services
5. **Digital Marketing** - Comprehensive digital marketing strategies
6. **Premium Resources** - Access to premium digital resources

## 🔧 Customization

### Modifying Services
Edit the fallback services in `config/database.js` or add services to the database.

### Styling
Modify the CSS variables in `public/css/style.css` to change colors and themes.

### Adding New Features
1. Add new API routes in `routes/api.js`
2. Update frontend in `public/index.html` and `public/js/main.js`

## 🐛 Troubleshooting

### Database Connection Issues
If you see "Database not available" message, the app will automatically run in demo mode. To fix:
- Ensure MySQL is running
- Check database credentials in `.env` file
- Run `database.sql` to create required tables

### Port Already in Use
If port 3000 is busy, modify the `PORT` in `.env` file.

### Dependencies Issues
Remove `node_modules` and reinstall:
```bash
rm -rf node_modules
npm install
```

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🔒 Security Notes

- Input validation on all forms
- SQL injection prevention with prepared statements
- XSS prevention with proper escaping
- CORS configuration for API security

## 🚀 Deployment

### Production Build
```bash
npm run build
```

### Deploy to Heroku
```bash
heroku create
git push heroku main
```

### Deploy to Vercel/Netlify
1. Build the project
2. Deploy the `public` folder

## 📄 License

MIT License - Copyright (c) 2026 The Digital Toolbox

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📞 Support

For support or questions:
- Email: info@digitaltoolbox.com
- Website: http://localhost:3000

---

**The Digital Toolbox** - Your trusted partner for premium digital solutions! 🚀
